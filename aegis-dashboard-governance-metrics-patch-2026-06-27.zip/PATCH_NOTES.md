# Aegis Dashboard Governance Metrics Patch Notes

## Files Changed

- `deploy/postgres/migrations/0011_dashboard_metrics.sql`
- `src/aegis_fabric/operational_metrics.py`
- `src/aegis_fabric/audit.py`
- `src/aegis_fabric/dashboard_api.py`
- `src/aegis_fabric/inspectors.py`
- `src/aegis_fabric/isa.py`
- `src/aegis_fabric/main.py`
- `src/aegis_fabric/memory.py`
- `src/aegis_fabric/models.py`
- `src/aegis_fabric/policy.py`
- `src/aegis_fabric/skill_runner.py`
- `src/aegis_fabric/tools.py`
- `src/aegis_fabric/usage.py`
- `src/aegis_fabric/workflow.py`
- `frontend/src/pages/Dashboard.jsx`
- `frontend/src/components/dashboard/MetricCard.jsx`
- `frontend/src/components/dashboard/SystemHealth.jsx`
- `frontend/src/components/dashboard/GovernanceCard.jsx`
- `frontend/src/components/dashboard/LatencyBreakdownChart.jsx`
- `frontend/src/components/dashboard/FinOpsSummary.jsx`
- `frontend/src/components/dashboard/AuditTraceSummary.jsx`
- `frontend/src/components/dashboard/RetrievalSummary.jsx`
- `frontend/src/components/dashboard/RecentDecisionsTable.jsx`

## Metrics Added

`GET /admin/dashboard/metrics` now returns:

- `summary`
- `governance`
- `latency`
- `finops`
- `audit`
- `retrieval`
- `system`
- `recent_decisions`
- `generated_at`

Executive cards include requests today, successful chat turns, error rate, p95 end-to-end latency,
estimated cost today, and tokens today.

Governance cards include policy allow rate, policy deny count, refusal rate, PII redactions applied,
trace coverage, ISA pass rate, budget refusals, prompt-injection findings, and cross-tenant leakage
alerts.

Latency includes p50/p95/p99 end-to-end latency plus p95 PDP, retrieval, model, PII inspection,
audit write, ISA verification, and FinOps write timings.

FinOps includes tokens today, estimated cost today, spend by tenant, spend by role, top spending
tenant, top spending role, budget burn, and projected daily spend.

Audit, retrieval, and system/load panels were added to the dashboard UI.

## Data Sources

- `audit_events`: policy allow/deny, trace IDs, audit event counts, deny reasons, recent decisions.
- `isas`: ISA pass rate.
- `roles.capabilities`: token budget denominator for budget burn.
- `dashboard_chat_metrics`: request status, end-to-end latency, tokens, redactions, refusals, leakage alerts.
- `dashboard_stage_metrics`: PDP, retrieval, model, PII, audit, ISA, and FinOps stage latencies.
- Process/runtime checks: active request count, Redis health, Postgres connection count, API memory.

The new dashboard metrics tables intentionally store only non-sensitive operational counters and timings.
They do not store prompts, answers, retrieved document bodies, credentials, or decrypted audit payloads.

## Limitations

- Historical rows before this patch will not have end-to-end/stage latency metrics.
- Estimated cost remains `not instrumented` until provider/model pricing is configured; token counts are tracked.
- API CPU %, Keycloak active sessions, and Caddy 502/504 counts are returned as `not instrumented`.
- The local governance smoke script could not complete because local OPA had no seeded RBAC data for `acme-corp`.
- `pnpm install` exited with an ignored `esbuild` build-script policy warning, but the Vite production build passed.
- No VM redeploy was run while creating this artifact.
- No live database seeding was run.

## Validation Commands

```bash
python3 -m compileall -q src
node ./frontend/node_modules/vite/bin/vite.js build
AEGIS_ENV=development DATABASE_URL='postgresql://aegis:aegis@localhost:5432/aegis' \
  OIDC_ISSUER='http://localhost:8081/realms/aegis' PYTHONPATH=src \
  uv run --no-project --with fastapi --with 'uvicorn[standard]' --with pydantic \
  --with pydantic-settings --with 'python-jose[cryptography]' --with cryptography \
  --with httpx --with 'psycopg[binary]' --with psycopg-pool --with pyyaml \
  --with docker --with hvac --with opentelemetry-api --with opentelemetry-sdk \
  --with opentelemetry-exporter-otlp --with opentelemetry-instrumentation-fastapi \
  --with opentelemetry-instrumentation-httpx --with tenacity --with typer --with rich \
  --with redis --with pymongo --with python-multipart \
  python -c 'from aegis_fabric.main import app; print(app.title, app.version)'
docker compose -f docker-compose.yml config
docker compose -f docker-compose.yml -f deploy/gcp/docker-compose.production.yml \
  --env-file deploy/gcp/.env.production.example config
bash scripts/test-governance.sh
```

Results:

- Python compile passed.
- Frontend production build passed with the existing large-bundle warning.
- API import/start check passed with development placeholder env vars.
- Both Docker Compose config commands passed.
- `scripts/test-governance.sh` stopped at preflight because local OPA lacked seeded RBAC data.

## Deployment Commands

After review, commit, and push:

```bash
git push origin main
```

On the VM:

```bash
cd /opt/aegis/aegis_platform
sudo git fetch origin main
sudo git reset --hard origin/main
sudo bash deploy/gcp/redeploy.sh
```

Migration `0011_dashboard_metrics.sql` is applied by the existing startup migration runner when the API starts
with migrations enabled.

Smoke after deploy:

```bash
curl -fsS "$URL/api/health"
curl -fsS "$URL/api/ready"
curl -fsS -H "Authorization: Bearer $PLATFORM_ADMIN_TOKEN" \
  "$URL/api/admin/dashboard/metrics"
```

Then open the dashboard as a platform admin and verify that non-admin users cannot access admin metrics.
