# Governance Test Data Augmentation Patch Notes

## 1. Files Changed

- `configs/fixtures/governance_test_fixture.yaml`
- `scripts/seed-governance-test-data.py`
- `scripts/reset-governance-test-data.py`
- `scripts/generate-governance-traffic.py`
- `tests/test_augmented_fixtures.py`
- `docs/AUGMENTED_TEST_DATA.md`
- `docs/TESTING_PROCEDURE.md`

## 2. Target Database Counts

Baseline plus augmentation targets:

- Tenants: 9
- Users: 102 total, adding 72 synthetic governance users
- Role templates: 12 total, adding 7 test-only role templates
- Memory documents: 270 total, adding 207 documents
- Values documents: 168 augmented documents across organization, department, team, role, and individual scopes
- Pending approvals: 18
- ISA rows: 54
- Turn feedback rows: 54

## 3. Roles Added

- `analyst-no-egress`
- `analyst-low-budget`
- `auditor`
- `approval-reviewer`
- `restricted-reader`
- `runtime-denied-engineer`
- `runtime-python-engineer`

## 4. Validation Commands Run

```bash
python3 -m compileall -q src
uv run --no-project --with pytest --with pyyaml pytest tests/test_augmented_fixtures.py -q
docker compose -f docker-compose.yml config
docker compose -f docker-compose.yml -f deploy/gcp/docker-compose.production.yml --env-file deploy/gcp/.env.production.example config
```

Additional local syntax validation:

```bash
python3 -m py_compile scripts/seed-governance-test-data.py scripts/reset-governance-test-data.py scripts/generate-governance-traffic.py tests/test_augmented_fixtures.py
```

## 5. VM Deployment Commands

Do not run these for packaging. After the patch is reviewed, committed, and pushed:

```bash
cd /opt/aegis/aegis_platform
sudo git fetch origin main
sudo git reset --hard origin/main
sudo bash deploy/gcp/redeploy.sh
```

## 6. Seeding Commands

Seed the augmentation idempotently:

```bash
cd /opt/aegis/aegis_platform
python3 scripts/seed-governance-test-data.py --reset-label-first
```

Optionally provision Keycloak logins for the new synthetic users:

```bash
export AEGIS_TEST_USER_PASSWORD='password'
python3 scripts/seed-governance-test-data.py --reset-label-first --provision-logins
```

Generate a dry-run traffic plan:

```bash
python3 scripts/generate-governance-traffic.py --turns 20 --label smoke --dry-run
```

Reset only the augmented rows:

```bash
python3 scripts/reset-governance-test-data.py --label capstone-demo-2026
```

## 7. Known Limitations

- No VM redeploy was run while creating this artifact.
- The live database was not seeded while creating this artifact.
- The traffic generator is dry-run/cost-safe by default when `--dry-run` or `--skip-model-call` is used; live `/v1/ask` traffic requires bearer tokens.
- Keycloak login provisioning is opt-in and requires `AEGIS_TEST_USER_PASSWORD`; no passwords or secrets are included.
- The seeder writes governance fixture rows directly for approvals, ISA, and feedback, while full Audit/FinOps runtime evidence should be generated through the traffic script against platform APIs.
