# Aegis Dashboard / FinOps Refactor Patch

Artifact: `aegis-dashboard-finops-refactor-patch-2026-06-27.zip`

## Files Changed

- `src/aegis_fabric/dashboard_api.py`
- `src/aegis_fabric/operational_metrics.py`
- `frontend/src/pages/Dashboard.jsx`
- `frontend/src/pages/FinOps.jsx`
- `frontend/src/components/dashboard/AuditTraceSummary.jsx`
- `frontend/src/components/dashboard/FinOpsSummary.jsx`
- `frontend/src/components/dashboard/GovernanceCard.jsx`
- `frontend/src/components/dashboard/InstrumentationGapsPanel.jsx`
- `frontend/src/components/dashboard/LatencyBreakdownChart.jsx`
- `frontend/src/components/dashboard/MetricCard.jsx`
- `frontend/src/components/dashboard/RecentDecisionsTable.jsx`
- `frontend/src/components/dashboard/RetrievalSummary.jsx`
- `frontend/src/components/dashboard/SystemHealth.jsx`
- `PATCH_NOTES.md`

## Metrics Moved From Dashboard to FinOps

- Tokens today
- Estimated cost today
- Average cost per chat turn
- Budget utilization
- Budget refusals
- Projected daily spend
- Spend by tenant, role, model, provider, and hour
- Token breakdown by tenant, role, model, provider, and hour
- Budget burn and top budget risks
- Recent FinOps token/cost/budget events

## Metrics Now Computed

Dashboard now focuses on governance operations:

- Requests today and successful chat turns from `dashboard_chat_metrics`, with audit fallback for legacy rows.
- Error rate and p95 end-to-end latency only when request lifecycle metrics exist.
- Policy allow rate and deny count from `audit_events`.
- Trace coverage from chat metric traces joined to audit trace IDs.
- ISA pass rate from `isas`.
- Prompt-injection findings from chat metrics and `security.inspect` audit events.
- Cross-tenant leakage alerts from retrieval stage metrics and chat metrics.
- Audit events today, rows per chat turn, deny reasons, recent trace IDs, and audit chain verification.
- Retrieval calls, returned documents, zero-result retrievals, namespace/classification breakdowns.
- System/load metrics for active requests, requests per minute, API memory, Postgres connections, Redis health, and model provider timeout/rate-limit counts.

FinOps now computes:

- Token totals from `dashboard_chat_metrics`.
- Cost totals only from recorded `estimated_cost_usd` rows.
- Budget utilization from role `token_budget_per_day` values and real token usage.
- Budget refusals from chat metrics with audit fallback.
- Model/provider token attribution from `dashboard_stage_metrics` model stages.

## Instrumentation Added

- Prevented double-counting token usage when provider-reported model usage already populated chat metrics.
- Kept unavailable dashboard metrics out of headline KPI cards and grouped them into `instrumentation_gaps`.
- Removed synthetic per-action cost estimates from `/admin/finops/summary`.
- Removed the previous hardcoded 32% budget-spend estimate from `/admin/finops/budget`.
- Scoped dashboard activity, FinOps summary, and FinOps budget data by existing admin principal scope.

## Remaining Gaps

- Cost is `null` until model-call cost attribution writes real `estimated_cost_usd`.
- API CPU percentage, Keycloak session counts, Caddy 502/504 counts, and external OPA health are listed as instrumentation gaps.
- Per-model/provider spend is shown only when both real cost and model stage attribution are available.
- Live VM smoke tests and private-browser manual verification were not run here because this patch request did not ask for redeploy.
- The workspace WSL image has no `npm` binary. Frontend install/build were validated with the bundled Codex Node runtime and pnpm.

## Validation Commands

Run locally:

```bash
python3 -m compileall -q src
python3 -m py_compile scripts/*.py || true
```

Structured JSON/TOML/YAML validation was run with generated folders excluded:

```bash
python3 - <<'PY'
import json, pathlib, sys, tomllib, yaml
excluded = {'.git', 'node_modules', 'dist', '.ruff_cache', '.pytest_cache', '__pycache__'}
count = 0
errors = []
for path in pathlib.Path('.').rglob('*'):
    if not path.is_file() or any(part in excluded for part in path.parts):
        continue
    suffix = path.suffix.lower()
    if suffix not in {'.json', '.toml', '.yaml', '.yml'}:
        continue
    try:
        data = path.read_bytes()
        if suffix == '.json':
            json.loads(data.decode('utf-8'))
        elif suffix == '.toml':
            tomllib.loads(data.decode('utf-8'))
        else:
            yaml.safe_load(data.decode('utf-8'))
        count += 1
    except Exception as exc:
        errors.append(f'{path}: {exc}')
if errors:
    print('\n'.join(errors))
    sys.exit(1)
print(f'validated {count} structured files')
PY
```

Frontend validation in this environment:

```powershell
$env:PATH = "C:\Users\noelg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin;$env:PATH"
Set-Location -LiteralPath "C:\Users\noelg\Documents\Other Documents\Industry project experimentation\ChatGPT_Enterprise AI agentic system\26062026\aegis\frontend"
& "C:\Users\noelg\.cache\codex-runtimes\codex-primary-runtime\dependencies\bin\pnpm.cmd" install --config.dangerously-allow-all-builds=true
& "C:\Users\noelg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" ".\node_modules\vite\bin\vite.js" build
```

Docker Compose validation:

```bash
docker compose -f docker-compose.yml config
docker compose -f docker-compose.yml -f deploy/gcp/docker-compose.production.yml --env-file deploy/gcp/.env.production.example config
```

API import/start check:

```bash
AEGIS_ENV=development \
DATABASE_URL='postgresql://aegis:aegis@localhost:5432/aegis' \
OIDC_ISSUER='http://localhost:8081/realms/aegis' \
PYTHONPATH=src \
uv run --no-project --link-mode=copy \
  --with fastapi --with 'uvicorn[standard]' --with pydantic --with pydantic-settings \
  --with 'python-jose[cryptography]' --with cryptography --with httpx \
  --with 'psycopg[binary]' --with psycopg-pool --with pyyaml --with docker --with hvac \
  --with opentelemetry-api --with opentelemetry-sdk --with opentelemetry-exporter-otlp \
  --with opentelemetry-instrumentation-fastapi --with opentelemetry-instrumentation-httpx \
  --with tenacity --with typer --with rich --with redis --with pymongo \
  --with python-docx --with pypdf --with python-multipart \
  python -c 'from aegis_fabric.main import app; print(app.title, app.version)'
```

## Deployment Commands

After applying and committing this patch:

```bash
cd /opt/aegis/aegis_platform
sudo git fetch origin main
sudo git reset --hard origin/main
sudo bash deploy/gcp/redeploy.sh
```

Post-deploy smoke checks:

```bash
curl -fsS https://aegis-34-58-134-152.nip.io >/dev/null
curl -fsS https://aegis-34-58-134-152.nip.io/config.js
curl -fsS https://aegis-34-58-134-152.nip.io/api/health
curl -fsS https://aegis-34-58-134-152.nip.io/auth/realms/aegis/.well-known/openid-configuration >/dev/null
```

## Manual Verification Checklist

- Login as `priya@it.example / password`.
- Open `Console -> Dashboard`.
- Confirm the dashboard has no noisy grid of unavailable KPI cards.
- Confirm cost, token, spend, budget burn, and projected spend metrics are absent from Dashboard.
- Confirm unavailable governance/system metrics appear only in the compact `Instrumentation gaps` panel.
- Confirm trace coverage, allow rate, deny count, ISA pass rate, prompt-injection findings, recent decisions, and system/load sections render.
- Open `Console -> FinOps`.
- Confirm tokens, estimated cost when available, budget refusals, budget utilization, spend breakdowns, token breakdowns, budget governance, and recent FinOps events live there.
- Confirm platform-admin sees platform-wide metrics, tenant-admin sees tenant-scoped metrics, and non-admins remain blocked.
